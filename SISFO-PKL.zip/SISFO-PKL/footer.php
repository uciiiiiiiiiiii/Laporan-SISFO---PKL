<footer>
    <p>SMEKDA Coding - Design By Candra</p>
</footer>