<header>
    <h1>Sistem Informasi PKL SMKN 9 Medan </h1>
    <p>Siswa - Halaman Untuk Isi Jurnal dan Absen Serta Konsultasi dengan Pembimbing</p>
</header>