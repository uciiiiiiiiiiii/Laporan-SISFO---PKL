<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Halaman Konsultasi</title>
</head>
<body>
<div class="chat-container">
    <h2>Konsultasi Chat</h2>
        <div class="chat-box" id="chatBox">
        </div>
        <input type="text" id="chatInput" class="chat-input" placeholder="Tulis pesan...">
        <button onclick="sendMessage()">Kirim</button>
</div>
<script>
    funtion sendMessage() {
        const chatInput = document.getElementById('chatInput');
        const chatBox = document.getElementById('chatBox');
        const message = chatInput.value.trim();

        if (massage) {
            const userMessage = document.createElement('div');
            userMessage.className = 'message user';
            userMessage.innerText = message;
            chatBox.appendChild(userMessage);

            const adminMessage = document.createElement('div');
            adminMessage.innerText = 'Admin : Terima kasih, pesan anda telah diterima';
            chatBox.appendChild(andminMessage);

            chatBox.scrollTop = chatBox.scrolHeight;

            chatInput.value ='';
        }
    }
</script>
</body>
</html>