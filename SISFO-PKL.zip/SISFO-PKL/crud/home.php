<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Halaman Home</title>
</head>
<body>
    <div class="chat-container">
        <h2>Selamat Datang di Sistem Informasi PKL SMKN 9 Medan</h2>
        <p>Sistem informasi PKL ini juga digunakan sebagai media konsultasi atau pembibingan bagi siswa 
            kepada guru pembimbing di sekolah . Silahkan anda berkonsultasi yang dihadapi di tempat kerja.
        </p>
    </div>
</body>
</html>